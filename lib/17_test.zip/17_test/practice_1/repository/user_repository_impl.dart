import 'package:learn_dart_together/17_test/practice_1/data_source/user_data_source.dart';
import 'package:learn_dart_together/17_test/practice_1/model/user.dart';
import 'package:learn_dart_together/17_test/practice_1/repository/user_repository.dart';

class UserRepositoryImpl implements UserRepository {
  final UserDataSource _dataSource;

  UserRepositoryImpl(this._dataSource);

  @override
  Future<String> createUser(User user) {
    return _dataSource.createUser(user);
  }

  @override
  Future<String> deleteUser(int id) async {
    return await _dataSource.deleteUser(id);
  }

  @override
  Future<List<User>> getAllUsers() async {
    return await _dataSource.getAllUsers();
  }

  @override
  Future<User> getUser(int id) async {
    return await _dataSource.getUser(id);
  }

  @override
  Future<User> updateUser(User user) async {
    return await _dataSource.updateUser(user);
  }

  @override
  Future<User> findUserByEmail(String email) async {
    List<User> users = await getAllUsers();
    return users.firstWhere((e) => e.email == email);
  }
}
