abstract interface class MaskStoreDataSource {}
